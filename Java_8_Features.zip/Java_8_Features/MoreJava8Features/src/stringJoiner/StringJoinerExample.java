/*	StringJoiner:
 *  =============
	StringJoiner is final class in java.util package which is used to construct sequence of characters separated by a delimiter. 
	We can create string by passing delimiter like hyphen(-), comma(,), etc. 
	Also we can add prefix and suffix to the character sequence.
	
	StringJoiner Constructors:
	--------------------------
	StringJoiner(CharSequence delimiter) - It constructs StringJoiner with no characters in it with no prefix or 
	suffix and copy of supplied delimiter.
	
	StringJoiner(CharSequence delimiter, CharSequence prefix, CharSequence suffix) - It constructs StringJoiner with no 
	characters in it with copies of supplied delimiter, prefix and suffix.
	
	Methods:
	--------
	length() - Returns length of string representation of StringJoiner.
	add(CharSequence newElem) - It adds specified character sequence as a next element in StringJoiner value.
								If specified sequence is null, "null" gets added to StringJoiner.
	merge(StringJoiner other) - It adds contents of given StringJoiner without prefix and suffix as next element in StringJoiner.
								If the given StringJoiner is empty, the call has no effect.
	setEmptyValue(CharSequence emptyValue) - It sets the given character sequence to the StringJoiner value when no elements 
											 are added in it (i.e it's empty).
*/
 
package stringJoiner;

import java.util.StringJoiner;

public class StringJoinerExample {

	public static void main(String[] args) {
		
		StringJoiner joiner1 = new StringJoiner(",");
		System.out.println("StringJoiner after initialization: "+ joiner1.setEmptyValue("Empty"));
		
		joiner1.add("Apple").add("Mango"); 
		System.out.println(joiner1);
		
		StringJoiner joiner2 = new StringJoiner(":","(",")");
		joiner2.add("Slice").add("Pepsi");
		System.out.println(joiner2);
		
		System.out.println("After Merge: "+ joiner1.merge(joiner2) );
		
		StringJoiner joiner3 = new StringJoiner("~","_","#");
		joiner3.add("Cake").add("IceCream").add("Biscuit");
		System.out.println(joiner3);
		
		System.out.println(joiner1.merge(joiner3));
		System.out.println(joiner3.merge(joiner2));
		System.out.println(joiner3);
		
		System.out.println("Length:"+ joiner1.length() +" & String Joiner: "+joiner1.toString()); // joiner1.toString() is same as joiner1
	}

}

/* Output:

StringJoiner after initialization: Empty
Apple,Mango
(Slice:Pepsi)
After Merge: Apple,Mango,Slice:Pepsi
_Cake~IceCream~Biscuit#
Apple,Mango,Slice:Pepsi,Cake~IceCream~Biscuit
_Cake~IceCream~Biscuit~Slice:Pepsi#
_Cake~IceCream~Biscuit~Slice:Pepsi#
Length:45 & String Joiner: Apple,Mango,Slice:Pepsi,Cake~IceCream~Biscuit

*/
