package optional;

public class WithoutOptionalClass {

	public static void main(String[] args) {
		String str[] = new String[10];
		System.out.println(str[5].length());
	}

}
