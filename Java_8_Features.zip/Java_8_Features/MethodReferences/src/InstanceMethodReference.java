interface InstanceIface
{
	void getMsg(String msg); // We can keep same method name as class method 
}
@FunctionalInterface
interface StringIface
{
	String strOp(String str);
}
interface SFace1
{
	int len();
}
interface SFace2
{
//	String getLowerCaseString(String s);
	String getLowerCaseString();
}
interface SFace3
{
	String getConcatedString(String s);
}
public class InstanceMethodReference {

	public void showMsg(String msg)
	{
		System.out.println(msg);
	}
	public static void main(String []args)
	{
		InstanceMethodReference reference = new InstanceMethodReference();
		InstanceIface iface = reference::showMsg;
		iface.getMsg("This is method reference to instance method of perticular object");
			
		InstanceIface instanceIface = new InstanceMethodReference()::showMsg;
		instanceIface.getMsg("This is method reference to instance method of perticular object");
		
		String s = "Welcome";
		StringIface i= String::toUpperCase;
		System.out.println(i.strOp(s));
		
		String str= new String("Welcome");
		SFace1 face1 = str :: length;
		System.out.println(face1.len());
		
		String lcase = new String("WELCOME");
		SFace2 face2 = lcase :: toLowerCase;
//		SFace2 face2 = String :: toLowerCase;   //***-IMP
		System.out.println(face2.getLowerCaseString());
		
		String str1 = new String("Hey, ");
		SFace3 face3 = str1 :: concat;
//		SFace2 face2 = String :: toLowerCase;   //***-IMP
		System.out.println(face3.getConcatedString("Welcome"));
		
	}
}
