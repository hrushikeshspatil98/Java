interface IFace
{
	Message getMessage(String msg);
}

class Message{
	
	public Message(String msg) {
		System.out.println("In Constructor: "+msg);
	}
}

public class ConstructorReference {

	public static void main(String[] args) {
		
		IFace iFace = Message::new;
		iFace.getMessage("Hello");
	}

}
