import java.util.function.BiFunction;

interface SMethodIface
{
	void showMessage(String msg);
}


//We can create custom generic functional interface abstract method
@FunctionalInterface
interface TriFunction<T,U,V,R>
{
	R sumOfNums(T t,U u,V v);
} 

public class StaticMethodReference {

	public static void getMsg(String msg)
	{
		System.out.println("In Static Method: "+msg);
	}
	
	public static void main(String[] args) {
		//Example 1
		SMethodIface sMethodIface = StaticMethodReference::getMsg;
		sMethodIface.showMessage("This is called using method reference" );
		
		//Example 2
		BiFunction<Integer, Integer, Integer> sum1= AdderCalc::add;
		BiFunction<Integer, Double, Double> sum2= AdderCalc::add;
		BiFunction<Double, Integer, Double> sum3= AdderCalc::add;
		BiFunction<Double, Double, Double> sum4= AdderCalc::add;
		TriFunction<Integer, Integer, Integer, Integer> sum5 = AdderCalc::add; //Custom Interface - TriFunction
		
		//Example 3
		System.out.println(sum1.apply(10, 20));
		System.out.println(sum2.apply(10, 30.5));
		System.out.println(sum3.apply(30.5, 10));
		System.out.println(sum4.apply(10.5, 30.5));
		System.out.println(sum5.sumOfNums(10, 20, 30));
		
		Thread t = new Thread(AdderCalc::showInfo);
		t.start(); 
	}

}

class AdderCalc
{
	static int add(int a, int b)
	{
		return a+b;
	}
	static Double add(int a, double b)
	{
		return a+b;
	}
	static Double add(Double a, int b)
	{
		return a+b;
	}
	static Double add(Double a, Double b)
	{
		return a+b;
	}
	static void showInfo()
	{
		System.out.println("This class is used for addition of two numbers.");
	}
	static Integer add(Integer a, Integer b, Integer c)
	{
		return a+b+c;
	}
}
