import java.io.FileReader;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class NashornJSEngine {

	public static void main(String[] args) {
		//It will work only if Nashorn JS Engine Available/Installed
		ScriptEngine jsEngine = new ScriptEngineManager().getEngineByName("nashorn");
		try {
			
			jsEngine.eval("print('Hello, Nashorn')");
			jsEngine.eval(new FileReader("C:\\Users\\hp959j\\Java_8_Features\\NashornJavaScriptEngine\\src\\hello.js"));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
