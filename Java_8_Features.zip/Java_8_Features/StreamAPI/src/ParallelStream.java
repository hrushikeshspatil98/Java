import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ParallelStream {

	public static void main(String[] args) {

		Stream.of(1,2,3,4,5).parallel().forEach(System.out::print);

		System.out.println();
		
		List<Integer> nums = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5,6));
		nums.parallelStream().filter(x -> x > 3).peek(x -> System.out.println("Filtered -> "+x)).forEach(System.out::println);
	}

}
