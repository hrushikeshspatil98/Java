import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Product
{
	int id;
	String name;
	int price;
	Product(int id,String name,int price)
	{
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
}

public class CustomObjectStream {

	public static void main(String[] args) {
		List<Product> pList = new ArrayList<Product>();
		Collections.addAll(pList,new Product(1,"Ice-Cream Pack",160),new Product(2, "Cake",250),
				new Product(3,"Pen",20), new Product(4,"Pencil",10), new Product(5,"Pen Drive",200));
		
		List<String> highPricePList = pList.stream().filter(p -> p.price>150).
				map(p -> p.name).collect(Collectors.toList());
		System.out.println(highPricePList);
		
		highPricePList.clear();
		
		highPricePList = pList.stream().filter(p -> p.price>150).
				map(Product :: getName).collect(Collectors.toList());
		System.out.println(highPricePList);
		
		pList.stream().filter(p -> p.price>150).
		map(Product :: getName).collect(Collectors.toList()).forEach(str -> System.out.print(str+ " "));
		System.out.println();
		
		List<Product> highPriceObjList = pList.stream().filter(p -> p.price>150).
				collect(Collectors.toList());
		System.out.println(highPriceObjList.toString());
		
		//Store in map, key-id, value-name
		Map<Integer, String> pMap = pList.stream().filter(p -> p.price>150)
				.collect(Collectors.toMap(p -> p.id, p -> p.name));
		System.out.println(pMap);
	}

}
