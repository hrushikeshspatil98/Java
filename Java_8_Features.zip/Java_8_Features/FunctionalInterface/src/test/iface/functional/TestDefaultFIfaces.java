package test.iface.functional;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

public class TestDefaultFIfaces<T> {

    public static void main(String[] args) {

    	TestDefaultFIfaces<String> obj = new TestDefaultFIfaces<String>();

        List<String> list = obj.supplier().get();
        System.out.println("List is: "+list.toString());
        
        String str = "Welcome";
        //String str = "Hi";
        Supplier<String> supplier = () ->  str.length()>6 ? str : str.concat(", How are you?");
        System.out.println(supplier.get());
        
        BooleanSupplier boolSupplier = () ->  str.length()>6 ? true : false;
        System.out.println(boolSupplier.getAsBoolean());
    }

    public Supplier<List<T>> supplier() {

        // lambda
    	return () -> new ArrayList<>();

        // constructor reference
        //return ArrayList::new;

    }

}