//File :
//	File is a class in java.io package which is used to represent a file/directory/drive in a system.
//	It provide many operations to perform on metadata of file or directory or drive. 

package io;

import java.io.File;
import java.io.IOException;

public class FileClassDemo {

	public static void main(String[] args) {
//		try {
			//File file = new File("H://LASRGUI/../data.txt");
			File file = new File("H://LASRGUI");
			System.out.println("File exists? "+ file.exists());
			System.out.println("Is a file? "+ file.isFile());
			System.out.println("Is a directory? "+ file.isDirectory());
			System.out.println("Is hidden? "+ file.isHidden());
			System.out.println("Absolute Path : "+ file.getAbsolutePath());
			System.out.println("Path: "+ file.getPath());
			try {
				System.out.println("Canonical Path: "+ file.getCanonicalPath());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
			System.out.println("Free Space : "+file.getFreeSpace()+ " bytes - "+file.getFreeSpace()/ (1024 * 1024 * 1024.0)+ " GB");
			System.out.println("Total Space: "+ file.getTotalSpace());
			System.out.println("Usable Space: "+ file.getUsableSpace());
			System.out.println("Used Space: "+ (file.getTotalSpace() - file.getFreeSpace()));
			System.out.println("Last Modified: "+ file.lastModified());
			
			System.out.println(file.getName()+ " is readable (has read permission) - "+ file.canRead());
			System.out.println(file.getName()+ " is writable (has write permission) - "+ file.canWrite());
			System.out.println(file.getName()+ " is executable (has executable permission) - "+ file.canExecute());
			
			file.setReadable(true);	//access granted
			file.setExecutable(true); //access granted
			file.setWritable(false);  //access revoked
			
			System.out.println("Parent folder/path: "+file.getParent());
			
			
			System.out.println("*******************");
			System.out.println("File Dirs: ");
			File []files =  File.listRoots();	//return file array representing drives present in a system
			for(File f : files)
			{
				System.out.println("Name: "+ f.getAbsolutePath());
			}
			
			System.out.println("*******************");
			file = new File("H:");
			String []sfiles = file.list();	//returns null if file object is representing a file not a directory. If it's a directory it will return file names present in it.
			for(String s : sfiles)
			{
				System.out.println("Name: "+ s);
			}
			
			//File[] lsFiles = file.listFiles(); // return null pointer if file obj represent an file, it only requires directory or drive. 
											   //Same as list() but it will return complete path of files e.g. H:/Test/a.txt, H:/Test/Dir1, H:/Test/image.png, ...
			
			System.out.println("*******************");
			String sfile = "H:/a.txt";
			File drive = new File(sfile);
			try {
				if(!drive.exists()) {
					System.out.println("File does not exists, created new file/directory.");
					//if(drive.isFile()) //if file does not present, file object will not consider it as a file or directory
					if(sfile.contains("txt"))
						drive.createNewFile();
					//if(drive.isDirectory())  //if file does not present, file object will not consider it as a file or directory
					if (!sfile.contains("txt"))
						drive.mkdir();
				}
				else
				{
					if(drive.isFile())
						drive.renameTo(new File("H:/sample_file.txt"));	//if path of object representing file is different than specified, then it will move file to specified path and rename it 
					if(drive.isDirectory())
						drive.renameTo(new File("H://sample_folder"));  //if path of object representing directory is different than specified, then it will move directory to specified path and rename it 
					
					System.out.println("File or Directory replaced with given name");
				}
				
				File delFile = new File("H://unused");
				delFile.delete();
				System.out.println(delFile.getAbsolutePath()+ " is deleted");
				
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
			
			boolean flag= new File("H:\\Sample\\S1").mkdirs();
			System.out.println("Creating 2 directories (1 new dir and 1 sub dir in it): "+flag);
			
			
//		}
//		catch(Exception e)
//		{
//			System.out.println(e.getMessage());
//		}
	}

}


//Output: File exists? true
//Is a file? true
//Is a directory? false
//Is hidden? false
//Absolute Path : H:\LASRGUI\data.txt
//Path: H:\LASRGUI\data.txt
//Canonical Path: H:\LASRGUI\data.txt
//Free Space : 5536244396032 bytes - 5156.029155731201 GB
//Total Space: 32545544183808
//Usable Space: 5536243986432
//Used Space: 27009300307968
//Last Modified: 1670338692580
//data.txt is readable (has read permission) - true
//data.txt is writable (has write permission) - true
//data.txt is executable (has executable permission) - true
//true
//Parent folder/path: H:\LASRGUI
//*******************
//File Dirs: 
//Name: C:\
//Name: H:\
//*******************
//Name: .bash_history
//Name: .config
//Name: .git
//
//Name: LASRGUI
//Name: logo.png
//Name: mongod.cfg
//Name: My Pictures
//Name: New folder
//Name: No Code AI - ppt ref.docx
//Name: NonPrd_Prod2.zip
//Name: op2.txt
//Name: Others
//Name: Output (2).txt
//Name: output.txt
//Name: Prev Issues.docx
//Name: prim_data.txt
//Name: Profile
//Name: Profile_Win10
//
//Name: students.txt
//Name: sup_integrate.txt
//Name: WINDOWS
//Name: ~$28174-Offerds.pdf
//Name: ~$py Rec - FSD.docx
//Name: ~$Sprint 4.xlsx
//*******************
//File or Directory replaced with given name
//H:/unused is deleted
//Creating 2 directories (1 new dir and 1 sub dir in it): false
