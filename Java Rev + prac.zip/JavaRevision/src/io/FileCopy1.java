package io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy1 {

	public static void main(String[] args) {
		
		try{
			FileInputStream fis = new FileInputStream("H:/sample.txt");
			FileOutputStream fos = new FileOutputStream("H:/sample_copy.txt");
			
			byte []arr = new byte[128];
			int c;
			while((c =fis.read(arr)) != -1) {  //reads 128 (or specified size) bytes of data from file 
				System.out.println("Writing bytes: "+ c);
				fos.write(arr,0,c);			   //writes 128 (or specified size) bytes of data into file 
				System.out.println("Number of bytes available: "+ fis.available());
				System.out.println("********************");
			}
			
//			above code is similar to below code
//			while(fis.read(arr) != -1)
//				fos.write(arr);
			fos.flush();
			
			fis.close();
			fos.close();
			System.out.println("\nFile Copied Successfully !");
		}
		catch(FileNotFoundException ex)
		{
			System.out.println(ex.getMessage());
		}
		catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}

	}

}

//Output:
//Writing bytes: 128
//Number of bytes available: 11
//********************
//Writing bytes: 11
//Number of bytes available: 0
//********************
//
//File Copied Successfully !


