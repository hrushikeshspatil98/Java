//DataInputStream or DataOutputStream:
//	It is a class used to read or write primitive types of data to or from a file. We can use RandomAccessFile class also.

package io;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class DataStream {

	public static void main(String[] args) {
		try {
			DataOutputStream dos = new DataOutputStream(new FileOutputStream("H:/ds_data.txt"));
			dos.write(20);
			dos.writeChar('C');
			dos.writeLong(123456789);
			dos.writeUTF("Java");
			dos.writeUTF("This is sample line");
			dos.close();
			
			DataInputStream dis = new DataInputStream(new FileInputStream("H:/ds_data.txt"));
			System.out.println(dis.read());
			System.out.println(dis.readChar());
			System.out.println(dis.readLong());
			System.out.println(dis.readUTF());
			System.out.println(dis.readUTF());
			dis.close();
			
			}
			catch(Exception e) {}
	}

}
