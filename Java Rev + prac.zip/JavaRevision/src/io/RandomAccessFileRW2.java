package io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

//writing primitive type values into file 
public class RandomAccessFileRW2 {

	public static void main(String[] args) {
		
		try {
			RandomAccessFile raf = new RandomAccessFile(new File("H:/prim_data.txt"), "rw");
			raf.writeChar('A');
			raf.writeByte(10);
			raf.writeShort(200);
			raf.writeInt(15000);
			raf.writeLong(313279289);
			raf.writeFloat(12.20f);
			raf.writeDouble(23.45);
			//raf.writeChars("RAF");
			raf.writeUTF("RAF");
			raf.writeBoolean(true);
			
			System.out.println("Data is written & Cursor is at "+ raf.getFilePointer()+ " position");
			raf.seek(0);	//move file pointer to starting of a file
			
			System.out.println(raf.readChar());
			System.out.println(raf.readByte());
			System.out.println(raf.readShort());
			System.out.println(raf.readInt());
			System.out.println(raf.readLong());
			System.out.println(raf.readFloat());
			System.out.println(raf.readDouble());
			System.out.println(raf.readUTF());
			System.out.println(raf.readBoolean());
			
			
			raf.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}catch(IOException e){
			System.out.println(e.getMessage());
		}

	}

}
