//Serialization: It is a process of converting an object into series of bytes and stores into file or transferred over stream. Use ObjectOutputStream class & writeObject() method.
//DeSerialization: It is a process of converting series of bytes which is coming from a file or stream into an object. Use ObjectInputStream class & readObject() method.

package io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable {	//class of object should implement Serializable interface for Serialization & DeSerialization, it's a empty interface used for type compatibility only
	int rno;
	String name;
	transient int age; //transient members can't be serialized, so JVM will store it's default value (for object/string literal: null, integer: 0, float/double: 0.0, boolean: false, ...)

	Student(int sno, String sname, int age) {
		this.rno = sno;
		this.name = sname;
		this.age = age;
	}

	public void display() {
		System.out.println("Role No: " + rno + " Name: " + name+ " Age: "+ age);
	}

	@Override
	public String toString() {
		return "Student [rno=" + rno + ", name=" + name + ", age=" + age + "]";
	}

}

public class ObjectRW {

	public static void main(String[] args) {

		try {
			System.out.println("Students :");
			FileOutputStream fos = new FileOutputStream("H:/students.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(new Student(1, "Sam", 23));
			oos.writeObject(new Student(2, "Max", 26));
			oos.flush();

			FileInputStream fis = new FileInputStream("H:/students.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Student s1 = (Student) ois.readObject();
			Student s2 = (Student) ois.readObject();
			
			s1.display();
			s2.display();
			
			fos.close();
			oos.close();
			fis.close();
			ois.close();

		} catch (FileNotFoundException ex) {
			System.out.println("Exception" + ex.getMessage());
		} catch (IOException ex) {
			System.out.println("Exception" + ex.getMessage());
		} catch (ClassNotFoundException ex) {
			System.out.println("Exception" + ex.getMessage());
		}
	}

}
