package io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileWrite {

	public static void main(String[] args) {
		
		try {
		FileOutputStream fos = new FileOutputStream("H:/output.txt");
//		FileOutputStream fos = new FileOutputStream("H:/output.txt",true);	//true for appending data into (end of) file
		String s = "[0607/232944.524:ERROR:crash_report_database_win.cc(429)] unexpected ";

		//Soln 1
		//fos.write(s.getBytes());
		
		//Soln 2
		byte []arr = s.getBytes();
		for(int i=0; i<arr.length; i++)
			fos.write(arr[i]); //automatic conversion of byte to integer is done 
		
		fos.flush();
		fos.close();
		System.out.println("Data Written Successfully !");
		}
		catch(FileNotFoundException ex)
		{
			System.out.println(ex.getMessage());
		}
		catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}
		
		
	}

}
