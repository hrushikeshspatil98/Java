package io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy {

	public static void main(String[] args) {
		try {
//		FileInputStream fis = new FileInputStream("H:/sample.txt");
//		FileOutputStream fos = new FileOutputStream("H:/sample_copy.txt");
			
		FileInputStream fis = new FileInputStream("H:/logo.png");
		FileOutputStream fos = new FileOutputStream("H:/logo_copy.png");
			
		int c;
		while((c = fis.read()) != -1)  //reads 1 byte of data from file
			fos.write(c);			   //writes 1 byte of data from file
		fos.flush();
		
		fis.close();
		fos.close();
		System.out.println("File Copied Successfully !");
		}
		catch(FileNotFoundException ex)
		{
			System.out.println(ex.getMessage());
		}
		catch(IOException ex)
		{
			System.out.println(ex.getMessage());
		}
	}

}

//Output:
//File Copied Successfully !