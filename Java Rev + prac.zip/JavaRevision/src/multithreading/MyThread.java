package multithreading;

public class MyThread {

	public static void main(String[] args) {

		System.out.println("In Main(): thread count is "+Thread.activeCount());
		Thread t= new Thread() {
			@Override
			public void run() {
				for(int i=0; i< 20; i++)
					System.out.println("Thread 2: "+ i);
			}
		};
		
		t.start();	//new thread started, it will invoke run method & starts execution concurrently
		System.out.println("Thread count is "+Thread.activeCount());
		
		//main thread continues it's execution concurrently (it's default thread)
		for(int i=0; i< 20; i++)
			System.out.println("Thread 1 (main): "+ i);
		
	}

}

//Output:
//In Main(): thread count is 1
///Thread count is 2
//Thread 1 (main): 0
//Thread 1 (main): 1
//Thread 1 (main): 2
//Thread 1 (main): 3
//Thread 1 (main): 4
//Thread 1 (main): 5
//Thread 1 (main): 6
//Thread 1 (main): 7
//Thread 1 (main): 8
//Thread 2: 0
//Thread 2: 1
//Thread 2: 2
//Thread 2: 3
//Thread 2: 4
//Thread 2: 5
//Thread 2: 6
//Thread 2: 7
//Thread 1 (main): 9
//Thread 1 (main): 10
//Thread 2: 8
//Thread 2: 9
//Thread 2: 10
//Thread 2: 11
//Thread 2: 12
//Thread 2: 13
//Thread 1 (main): 11
//Thread 1 (main): 12
//Thread 1 (main): 13
//Thread 1 (main): 14
//Thread 2: 14
//Thread 2: 15
//Thread 2: 16
//Thread 2: 17
//Thread 2: 18
//Thread 2: 19
//Thread 1 (main): 15
//Thread 1 (main): 16
//Thread 1 (main): 17
//Thread 1 (main): 18
//Thread 1 (main): 19
