package multithreading;

public class ThreadSync {

}
