package multithreading;

public class MyThreadUsingRunnableIface implements Runnable{

	Thread t;
	
	MyThreadUsingRunnableIface()
	{
		t = new Thread(this);
		t.start();
	}
	
	@Override
	public void run() {
		for(int i=0; i<30; i++)
			System.out.print("B ");
	}
	
	public static void main(String []cmargs)
	{
		new MyThreadUsingRunnableIface();
		System.out.println("No of active threads: "+ Thread.activeCount());
		
		for(int i=0; i<30; i++)
			System.out.print("A ");
		
	}

}

//Output:

//Run 1:
//No of active threads: 2
//A B B B B B B B B B B B B B B B B B B B B B B B B B B B B B B A A A A A A A A A A A A A A A A A A A A A A A A A A A A A 

//Run 2:
//No of active threads: 2
//B B B B B B B B B B B B B B B B B B B B B B B B B B B B B B A A A A A A A A A A A A A A A A A A A A A A A A A A A A A A 