package multithreading;

public class ThreadType extends Thread{

	public ThreadType() {
		setDaemon(true); //need to specify before thread starts execution
		start();
	}
	
//	If we are creating thread by implementing Runnable interface
//	public ThreadType() {
//		Thread t = new Thread();
//		t.setDaemon(true);
//		t.start();
//	}
	
	@Override
	public void run()
	{
		for(int i=0; i<100;i++)
		{
			System.out.print("B"+i);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	
	public static void main(String[] args) {
		
		@SuppressWarnings("unused")
		ThreadType t = new ThreadType();
		//t.start(); //start method cannot be invoked more than one time, as it will give IllegalThreadStateException
		
		for(int i=0; i<50; i++)
		{
			System.out.print("A"+i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				System.out.println("Exception :"+ e.getMessage());
			}
		}
	}

}


//Output:
//A0B0A1A2A3A4B1A5A6A7A8A9B2A10A11A12A13A14B3A15A16A17A18B4A19A20A21A22A23B5A24A25A26A27A28
//B6A29A30A31A32A33B7A34A35A36A37B8A38A39A40A41A42B9A43A44A45A46A47B10A48A49 
//Note: Here main (non-daemon) thread completed all it's assigned subtask but custom (we have set it as daemon) thread has not executed all it's assigned task.
//Reason is daemon thread will be only executed till all other non-daemon threads are alive. once all non-daemon threads finishes their task daemon thread will 
//be moved to terminated or dead state.