package multithreading;

public class ThreadLifeCycle {
	

	public static void main(String[] args) {
		
	System.out.println("Current state of main thread : "+ Thread.currentThread().getState());
		
	Thread t =new Thread() { 
		@Override
		public void run()
		{
			for(int i=0; i< 10; i++)
			{
				System.err.print("A"+ i);
				try {
					Thread.sleep(1000);
					System.out.println("Current state of thread after sleep method: "+ this.getState());
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} 
			System.out.println("Current state of thread in run() method: "+ this.getState());
		}
	};
	System.out.println("Current state of thread after object is created: "+ t.getState());
	t.start();
	System.out.println("Current state of thread after invoking start method: "+ t.getState());
	
	for(int i=0; i<10; i++) {
		System.err.print("B"+i);
		try {
			Thread.sleep(2000);
			System.out.println("Current state of thread after sleep method: "+ Thread.currentThread().getState());
			
			if(i==3)
				Thread.currentThread().join();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Current state of new thread while executing main thread : "+ t.getState());
	}
	}

}

//Output:
//Current state of main thread : RUNNABLE
//Current state of thread after object is created: NEW
//Current state of thread after invoking start method: RUNNABLE
//B0A0Current state of thread after sleep method: RUNNABLE
//A1Current state of thread after sleep method: RUNNABLE
//B1Current state of new thread while executing main thread : TIMED_WAITING
//Current state of thread after sleep method: RUNNABLE
//A2Current state of thread after sleep method: RUNNABLE
//Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TIMED_WAITING
//Current state of thread after sleep method: RUNNABLE
//A3B2A4Current state of thread after sleep method: RUNNABLE
//A5Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TIMED_WAITING
//B3Current state of thread after sleep method: RUNNABLE
//A6Current state of thread after sleep method: RUNNABLE
//A7Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TIMED_WAITING
//B4Current state of thread after sleep method: RUNNABLE
//A8Current state of thread after sleep method: RUNNABLE
//A9Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TIMED_WAITING
//B5Current state of thread after sleep method: RUNNABLE
//Current state of thread in run() method: RUNNABLE
//Current state of thread after sleep method: RUNNABLE
//B6Current state of new thread while executing main thread : TERMINATED
//Current state of thread after sleep method: RUNNABLE
//B7Current state of new thread while executing main thread : TERMINATED
//Current state of thread after sleep method: RUNNABLE
//B8Current state of new thread while executing main thread : TERMINATED
//Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TERMINATED
//B9Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TERMINATED


//another run :
//Current state of main thread : RUNNABLE
//Current state of thread after object is created: NEW
//Current state of thread after invoking start method: RUNNABLE
//B0A0Current state of thread after sleep method: RUNNABLE
//A1Current state of thread after sleep method: RUNNABLE
//A2Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TIMED_WAITING
//B1Current state of thread after sleep method: RUNNABLE
//A3Current state of thread after sleep method: RUNNABLE
//B2A4Current state of new thread while executing main thread : BLOCKED
//Current state of thread after sleep method: RUNNABLE
//Current state of thread after sleep method: RUNNABLE
//A5Current state of thread after sleep method: RUNNABLE
//Current state of new thread while executing main thread : TIMED_WAITING
//B3Current state of thread after sleep method: RUNNABLE
//A6Current state of thread after sleep method: RUNNABLE
//A7Current state of thread after sleep method: RUNNABLE
//Current state of thread after sleep method: RUNNABLE
//A8Current state of thread after sleep method: RUNNABLE
//A9Current state of thread after sleep method: RUNNABLE
//Current state of thread in run() method: RUNNABLE


