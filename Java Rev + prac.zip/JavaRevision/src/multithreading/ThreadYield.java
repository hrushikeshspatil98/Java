package multithreading;

public class ThreadYield implements Runnable{
	
	@Override
	public void run() {
		
		for(int i=0; i<100; i++)
		{
			System.out.print(" B"+i);			
		}
	}

	public static void main(String[] args) {
		Runnable t1 = new ThreadYield();
		Thread t = new Thread(t1);
		t.start();
		
		for(int i=0; i<100; i++)
		{
			if(i > 40)
				Thread.yield();
			System.out.print(" A"+i);	 
		}
	}

}


//Output:  //yield method gave main thread execution (current) time quantum to thread t when i>40
//A0 B0 B1 B2 B3 A1 A2 A3 A4 A5 A6 A7 A8 B4 B5 A9 A10 A11 A12 A13 A14 B6 B7 B8 B9 B10 B11 B12 B13 B14 B15 B16 B17 B18 A15 B19 B20 B21 B22 B23 B24 B25 B26 B27 B28 B29 
//A16 A17 A18 B30 B31 B32 B33 A19 B34 A20 A21 A22 A23 A24 A25 A26 A27 A28 A29 A30 A31 A32 A33 A34 A35 A36 A37 A38 A39 A40 B35 B36 B37 B38 B39 B40 B41 B42 B43 A41 B44 B45 B46 
//B47 B48 B49 B50 A42 B51 A43 B52 B53 B54 A44 B55 B56 B57 B58 B59 B60 A45 B61 B62 B63 A46 B64 B65 B66 B67 B68 B69 B70 B71 B72 B73 B74 B75 B76 B77 B78 A47 B79 B80 B81 B82 B83 
//A48 B84 B85 B86 B87 B88 A49 B89 B90 B91 B92 B93 B94 B95 B96 B97 B98 B99 A50 A51 A52 A53 A54 A55 A56 A57 A58 A59 A60 A61 A62 A63 A64 A65 A66 A67 A68 A69 A70 A71 A72 A73 A74 
//A75 A76 A77 A78 A79 A80 A81 A82 A83 A84 A85 A86 A87 A88 A89 A90 A91 A92 A93 A94 A95 A96 A97 A98 A99