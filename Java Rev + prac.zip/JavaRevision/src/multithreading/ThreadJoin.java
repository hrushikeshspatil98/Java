package multithreading;

class NewThread extends Thread
{
	int ref;
	public NewThread(int ref) {
		this.ref = ref;
	}
	
	@Override
	public void run() {
		if(ref == 1)
			dispB();
		if(ref == 2)
			dispC();
	}

	private void dispC() {
		for(int i=0; i<10; i++)
		{
			System.out.print(" C"+i+" ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void dispB() {
		for(int i=0; i<30; i++)
		{
			System.out.print(" B"+i+" ");
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}		
	}
}
public class ThreadJoin {

	public static void main(String[] args) {
		
		NewThread n1 = new NewThread(1);
		NewThread n2 = new NewThread(2);
		
		n1.setName("n1");
		n2.setName("n2");
		
		n1.start();
		n2.start();
		
		
		for(int i=0; i<100; i++)
		{
			try {
				if(i==20)
					n1.join();
				if(i==40)
					n2.join(); //n2.join(6000);
				System.out.print(" A"+i+" ");
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
		}

	}

}


//Output:
//for 2 threads
// A0  A1  A2  A3  A4  A5  A6  A7  A8  A9  A10  A11  A12  A13  A14  A15  A16  A17  A18  A19  -- now main thread will get suspended & resumed once n1 thread complete its execution
// B0  B1  B2  B3  B4  B5  B6  B7  B8  B9  B10  B11  B12  B13  B14  B15  B16  B17  B18  B19  B20  B21  B22  B23  B24  B25  B26  B27  B28  B29  
// A20  A21  A22  A23  A24  A25  A26  A27  A28  A29  A30  A31  A32  A33  A34  A35  A36  A37  A38  A39  A40  A41  A42  A43  A44  A45  A46  A47  A48  A49  A50  A51  A52  A53  A54  A55  A56  A57  A58  A59  A60  A61  A62  A63  A64  A65  A66  A67  A68  A69  A70  A71  A72  A73  A74  A75  A76  A77  A78  A79  A80  A81  A82  A83  A84  A85  A86  A87  A88  A89  A90  A91  A92  A93  A94  A95  A96  A97  A98  A99 

//for 3 threads -- main thread allows to complete thread n1 & n2 to execute first and then it finishes it's task at end
// A0  B0  C0  A1  A2  A3  A4  A5  A6  A7  A8  A9  A10  A11  A12  A13  A14  A15  A16  A17  A18  A19  
// B1  B2  B3  B4  C1  B5  B6  B7  B8  B9  C2  B10  B11  B12  B13  B14  C3  B15  B16  B17  B18  B19  C4  B20  B21  B22  B23  B24  C5  B25  B26  B27  B28  B29  C6  A20  A21  A22  A23  A24  A25  A26  A27  A28  A29  A30  A31  A32  A33  A34  A35  A36  A37  A38  A39  
// C7  C8  C9  A40  A41  A42  A43  A44  A45  A46  A47  A48  A49  A50  A51  A52  A53  A54  A55  A56  A57  A58  A59  A60  A61  A62  A63  A64  A65  A66  A67  A68  A69  A70  A71  A72  A73  A74  A75  A76  A77  A78  A79  A80  A81  A82  A83  A84  A85  A86  A87  A88  A89  A90  A91  A92  A93  A94  A95  A96  A97  A98  A99 