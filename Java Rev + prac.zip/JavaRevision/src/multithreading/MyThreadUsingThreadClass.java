package multithreading;

public class MyThreadUsingThreadClass extends Thread{

	int flag = 0;
	
	public MyThreadUsingThreadClass(int val) {
		this.flag = val;
		System.out.println("Thread "+ val + " Started..");
		//start(); //we can give start call here also, will save some code (line no 17 & 18)
	}
	public static void main(String[] args) {
		//main Thread Starts here i.e Thread 1 starts
		
		MyThreadUsingThreadClass t1 = new MyThreadUsingThreadClass(1);
		MyThreadUsingThreadClass t2 = new MyThreadUsingThreadClass(2);
		
		t1.start(); //Thread 2 starts
		t2.start(); //Thread 3 starts
		
		System.out.println("Current Active Threads Count: "+Thread.activeCount());
		
		for(int i=0; i<50; i++)
			System.out.print("A"+i);
	}
	
	@Override
	public void run() {
		if(this.flag == 1)
			dispB();
		if(this.flag == 2)
			dispC();
	}
	
	private void dispC() {
		for(int i=0; i<50; i++)
			System.out.print("B"+i);
		
	}
	private void dispB() {
		for(int i=0; i<50; i++)
			System.out.print("C"+i);
	}
}

//Output: ( can be different on each run, as time span/period given for each thread will be decided by JVM )

//Thread 1 Started..
//Thread 2 Started..
//Current Active Threads Count: 3
//A0A1A2A3A4A5A6A7A8A9A10A11A12A13A14A15A16A17A18A19A20A21A22A23A24A25A26A27A28A29A30A31A32A33A34A35A36A37A38A39A40A41A42A43A44A45A46A47A48A49C0C1C2C3C4C5C6C7C8C9C10C11C12C13C14C15C16C17C18C19C20C21C22C23C24C25C26C27C28C29C30C31C32C33C34C35C36C37C38C39C40C41C42C43C44C45C46C47C48C49B0B1B2B3B4B5B6B7B8B9B10B11B12B13B14B15B16B17B18B19B20B21B22B23B24B25B26B27B28B29B30B31B32B33B34B35B36B37B38B39B40B41B42B43B44B45B46B47B48B49
//	or
//A0B0C0B1A1A2A3A4A5A6A7A8A9C1A10A11A12A13A14B2A15A16A17A18A19A20A21A22A23A24A25A26A27C2C3C4C5C6C7C8C9C10C11C12A28A29B3A30A31A32A33A34A35A36A37A38A39A40A41A42A43A44A45A46A47A48A49C13C14C15C16C17B4B5B6B7B8C18C19C20C21C22C23B9B10B11B12B13B14B15B16B17B18C24C25C26C27C28C29C30C31C32C33C34C35C36C37C38C39C40B19B20B21B22B23B24B25B26B27B28B29B30B31B32B33B34B35B36B37B38B39B40B41B42B43B44B45B46B47B48B49C41C42C43C44C45C46C47C48C49
