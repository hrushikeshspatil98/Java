//Thread Sleep: (method: sleep() )
//Sleep method ceases current thread execution for specific period of time.
//Accuracy of sleep depends on system's timer or schedulers.
//Call to sleep method throws InterrupedException which needs to be handled by caller.

package multithreading;

import java.awt.Toolkit;

public class ThreadSleep implements Runnable{

	Thread t;
	
	public ThreadSleep() {
		t = new Thread(this);
		t.start();
	}
	
	@Override
	public void run()
	{
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		
		for(int i=0; i< 20; i++)
		{
			toolkit.beep();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		
		new ThreadSleep();
		
		for(int i=0; i< 20; i++)
		{
			System.out.println(" A"+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
