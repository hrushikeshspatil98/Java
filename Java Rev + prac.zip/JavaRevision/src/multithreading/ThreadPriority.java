package multithreading;

public class ThreadPriority implements Runnable{

	public static void main(String[] args) {
		
		Thread currThread = Thread.currentThread();
		System.out.println("Current Thread and it's priority: "+ currThread.getName()+ " - "+ currThread.getPriority());
		
		Runnable runTh = new ThreadPriority();
		Thread t= new  Thread(runTh);
		t.start();
		System.out.println("New Thread Default Priority: "+ t.getPriority());
		t.setPriority(8);
		System.out.println("New thread current priority: "+ t.getPriority());
		
		for(int i=0; i<30; i++)
		{
			System.out.print(" B"+i);
		}
	}

	@Override
	public void run() {
		for(int i=0; i<30; i++)
			System.out.print(" A"+i);
	}

}
