package basic;
/*
Singleton class is a class that can be instantiated only once. 
Only one object of that class is created and returned same always.

To make a class as singleton class we need to follow below 2 steps:
1) Hide all constructors of a class (declare it as private)
2) Define static method in a class that creates one object and returns the same every time.
*/

class Ston
{
	private static Ston flag = null;
	private int x;
	int y;
	
	private Ston()
	{
		x = 10;
		y = 20;
	}
	
	static Ston getObject()
	{
		if(flag == null)
			flag = new Ston();
		return flag;
	}
	
	void display()
	{
		System.out.println("Multiplied Result: "+x*y);
	}
}
public class SingletonExample {

	public static void main(String[] args) {
		
		Ston s1 = Ston.getObject();
		Ston s2 = Ston.getObject();
		
		if(s1 == s2)
			System.out.println("Both Objects/instances are same "+s1+ " & "+s2);
		else
			System.out.println("Both Objects/instances are different.");
		
		s1.display();
		//s2.display(); //will display same result as above
	}

}

/*
Output:
Both Objects/instances are same Ston@1ee0005 & Ston@1ee0005
Multiplied Result: 200
Multiplied Result: 200
*/