package basic;

import basic.OuterEx3.InnerStaticClass;

class OuterEx3
{
	static int count = 0;
	int l;
	
	public OuterEx3() {
		l = 7;
	}
	
	static class InnerStaticClass
	{
		int w;
		static int h;
		
		{	w = 10;	}
		static {h = 20;}
		
		InnerStaticClass()
		{
			System.out.println("Static Class: constructor");
		}
		
		void calc()
		{
			count++;
			System.out.println("Count is: "+count+", Res is: "+(w*h+new OuterEx3().l)); 
		//It can't access non static members of outer class directly. We can create object and access it (eg. "l" data member in outer class)
		}
		
		static void soln()
		{	count++;
			System.out.println("Count is: "+count+", Res is: "+ ( new InnerStaticClass().w+h*new OuterEx3().l) );	
		}
	}
}
public class StaticNestedClass {

	public static void main(String[] args) {
		OuterEx3.InnerStaticClass staticClass = new OuterEx3.InnerStaticClass();
		staticClass.calc();
		InnerStaticClass.soln();
	}

}
