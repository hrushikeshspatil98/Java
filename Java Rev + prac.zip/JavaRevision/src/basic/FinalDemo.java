package basic;
/* 
 * final is keyword in java. We can declare 
 * 1. classes
 * 2. methods and 
 * 3. variables, arrays, etc as final.
 * 
 * final class is a class that cannot be inherited.
 * final method is a method that cannot be overridden.
 * final variables/ data members are cannot be modified/reassigned once it's declared and initialized. After that it becomes read only.
 */

final class Test1
{
	void demo()
	{
		System.out.println("Test 1");
	}
}

//It will give error as we are creating sub-class that extends final class 
//class Test2 extends Test1 {} 

class Test3
{
	final void demo()
	{
		System.out.println("Test 3");
	}
}
class Test4 extends Test3
{
	// It will give error as we cannot override final method from super class
	//void demo() {} 
	
	final double pi;
	final double constVal;
	
	{ pi = 3.14; }
	
	void finalDemo()
	{
		//constVal = 31.5; 
		//not allowed, we need to specify final data members value either while declaration or in initializer block or constructor
		System.out.println(constVal);
	}
	
	//If multiple constructors are present initialization in all is needed else specify in initializer block.
	Test4(int r)
	{
		constVal = 31.5;
	}
	
	Test4()
	{
		constVal = 31.5;
	}
}

public class FinalDemo {

	public static void main(String[] args) {
		new Test4().finalDemo();
		final double piVal ;
		piVal = 3.14;
		System.out.println("Value of pi is: "+piVal); 
	}

}
