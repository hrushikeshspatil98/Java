package basic;



abstract class AbstractClassEx{
	abstract void display();
	
	void print()
	{
		System.out.println("Abstract Class Non Static Method");
	}
	
	{System.out.println("NSIN - Abstract Class");}
	static {System.out.println("SIN - Abstract Class");}
}

interface IfaceAno
{
	void dispData();
	
	default void test()
	{
		System.out.println("Default test method");
		//pData(); // will work only in java 9 or more
	}
	
	/*
	private void pData()
	{
		System.out.println("Private Test Method");
	}
	*/
}

public  class AnonymousInnerClass {

	public static void main(String[] args) {
		
		AbstractClassEx abstractClassEx = new AbstractClassEx() {   
			
			@Override
			void display() {
				System.out.println("Anonymous Class Method 1");
			}
			
		};
		
		/*
		 * AbstractClassEx a1 = new AbstractClassEx() {
		 * 
		 * @Override void display() { // TODO Auto-generated method stub
		 * System.out.println("Anonymous Class Method 2"); } };
		 */
		
		abstractClassEx.display();
		abstractClassEx.print();
		
		IfaceAno ano = new IfaceAno() {
			
			@Override
			public void dispData() {
				System.out.println("Method for displaying data");
			}
		};
		
		ano.dispData();
		ano.test();
		
		
	}

}
