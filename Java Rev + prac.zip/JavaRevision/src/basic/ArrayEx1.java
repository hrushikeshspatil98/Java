package basic;

import java.util.Arrays;

public class ArrayEx1 {

	public static void main(String []args)
	{
		
		int arr[] = {-8, 1, -4, -6, 5, 6, -7, 1, 9, -4, -3, 6, 15, -1, 12 ,11, 14, -15, -20, -21, 70}; //Sort Algorithm - Insertion
		
		
		for(int i=1; i< arr.length; i++)
		{
			int key = arr[i]; 
			int j= i -1;	
			
			//if(key > 0)	continue; //for unsorted order
			
			//while(j>=0 && arr[j]>0) ////for unsorted order
			while(j>=0 && arr[j]>key)
			{
				arr[j+1] = arr[j]; 
				j--;
			}
			
			arr[j+1] = key;
			
			//Arrays.stream(arr).forEach(num -> System.out.print(num +" "));
			//System.out.println();
		}
		
		Arrays.stream(arr).forEach(num -> System.out.print(num +" "));
		
		System.out.println("\n****************"); 
		rearrangeNums(arr);
	}
//{1, -4, -6,5,6, -7,7,1}
	private static void rearrangeNums(int[] arr) {
		System.out.println("Moving -ve values at end");
		int i =0 , j = arr.length-1;
		
		// Negative Positive Alternative's
		while(i< j)
		{
			while(arr[i]>0)
			{
				i++;
			}
			while(arr[j]<0)
			{
				j--;
			}
			if(i < j)
				swap(arr,i,j);
		}
		
		if(i == 0 || i == arr.length)
			return;
		
		int k = 0;
		while(k < arr.length && i< arr.length)
		{
			swap(arr,k,i);
			i += 1;
			k += 2;
		}
		
		
		/*	// Positive Negative Alternative's
		while(i < j)
		{
			while(arr[i] < 0)
			{
				i++;
			}
			while(arr[j] > 0)
			{
				j--;
			}
			
			if(i< j)
				swap(arr, i, j);
		}
		
		if(i == 0 || i == arr.length)
			return;
					
		int k = 0; 
		while(k < arr.length && i < arr.length && k<i)
		{
			swap(arr,k,i);
			i+=1;
			k+=2;
		}
		*/
		
		Arrays.stream(arr).forEach(num -> System.out.print(num +" "));
	}
	
	public static void swap(int[] arr, int i, int j) {
		arr[i] += arr[j];
		arr[j] = arr[i]-arr[j];
		arr[i] -= arr[j];
	}
	
}
