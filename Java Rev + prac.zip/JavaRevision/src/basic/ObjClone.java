package basic;

public class ObjClone implements Cloneable {

	int num;

	{
		num = 20;
	}
	
//	@Override
//	protected Object clone() throws CloneNotSupportedException {
//		System.out.println("Custom Clone Method");
//		return super.clone();
//	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ObjClone obj1 = new ObjClone();
			ObjClone obj2 = null;

			obj2 = (ObjClone) obj1.clone();
			System.out.println("Object Cloned, num : "+obj2.num);
		} catch (CloneNotSupportedException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
