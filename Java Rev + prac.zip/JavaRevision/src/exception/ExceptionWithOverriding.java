package exception;

class Super
{
	//If super class method does not declare (throws) exception
	void test()
	{
		System.out.println("Super Class Methood");
	}
}
class Sub extends Super
{
	//then subclass overridden method can declare unchecked exception or not
	//but checked exception is not allowed
	//void test() 
	//void test() throws IOException - will give compiler err as it's checked exception
	void test() throws ArithmeticException
	{
		System.out.println("Sub Class Methood");
	}
}

class Parent
{
	//If super class method declares (throws) an exception
	//void test() throws ArithmeticException //1
	void test() throws Exception //2
	{
		System.out.println("Parent Class Methood");
	}
}
class Child extends Parent
{
	//void test()  //1. No Exception - allowed
	//void test() throws Exception  //1. Parent Class of Parent method exception - not allowed (checked case)
	//void test() throws ArithmeticException //1. same exception as super class  - allowed
	void test() throws ArithmeticException //2 - only unchecked exception, for checked exception - compile time error if we not surround by try-catch to the method call
	{
		System.out.println("Child Class Methood");
	}
}

public class ExceptionWithOverriding {

	public static void main(String[] args) {
		Sub s = new Sub();
		s.test();
		
		Child c =new Child();
		c.test();
	}

}
