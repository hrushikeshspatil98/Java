package exception;

class EmailDomainNotValidException extends Exception  //custom exception
{
	String message;
	
	public EmailDomainNotValidException(String s) {
		message = s.toUpperCase();
	}
	
	@Override
	public String getMessage()
	{
		return "EmailDomainNotValidException : "+ message;
	}

}

public class CustomException {

	public static void main(String[] args) {
//		String email = "abc@gmail.com";
		String email = "abc@cmail.com";
		
		try {  //block of code which can raise a exception
			
		 if(isValidDomain(email))
		 {
			System.out.println(email+ " is having valid domain"); 
		 }
		 else
		 {
			 throw new EmailDomainNotValidException("Domain Not Valid");
		 }
		 
		 System.out.println("Thank You, Perfect Email Id");
		 
		}
		catch(EmailDomainNotValidException e) //block of code to handle the exception
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("Details are below ->");
		}
		
		System.out.println("Email id is : "+email);
		System.out.println("Domain is: "+email.substring(email.indexOf("@")+1));
	}

	private static boolean isValidDomain(String email) {
		
		if(email.substring(email.indexOf('@')+1).equals("gmail.com"))
		{
			return true;
		}
		return false;
	}

}

/* 
Output: 

EmailDomainNotValidException : DOMAIN NOT VALID
Details are below ->
Email id is : abc@cmail.com
Domain is: cmail.com
*/
