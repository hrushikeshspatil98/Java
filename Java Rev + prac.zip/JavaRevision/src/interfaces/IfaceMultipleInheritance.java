package interfaces;

interface A
{
	void test();
	void dispData1();
}

interface B
{
	default void testDef()
	{
		System.out.println("Default method in Iface B");
	}
	void test();
}

interface C extends A,B
{
	void dispData1();
	
	default void testDef()
	{
		System.out.println("Default method in Iface C");
	}
}

public class IfaceMultipleInheritance implements C{

	@Override
	public void dispData1() {
		System.out.println("Display data");
		
	}

	@Override
	public void test() {
		System.out.println("test method");
		
	}

	public static void main(String ...args)
	{
		C c = new IfaceMultipleInheritance();
		c.test();
		c.testDef();
		c.dispData1();
		
		class Sample implements B
		{
			@Override
			public void test() {
				System.out.println("test method in Iface B");
			}
		}
		
		B b =new Sample();
		b.test();
		b.testDef();
	}
	

}
