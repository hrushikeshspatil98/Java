/*
 * StringBuilder :
 *	It's a class that is used to create mutable (modifiable) string objects in java. 
 *  It is non synchronized and thread unsafe i.e. multiple threads can access it simultaneously.
*/	

package strings;

public class StringBuilderEx {

	public static void main(String[] args) {
		
		StringBuilder sb1 = new StringBuilder();	//creates empty string buffer with initial capacity 16
		StringBuilder sb2 = new StringBuilder("welcome"); 
		StringBuilder sb3 = new StringBuilder(7); 
		sb3.append("welcome");
		sb3.append(true).append(3.14).append("hpn", 1, 3);
		
		System.out.println("String is: "+ sb1 +", Capacity: "+ sb1.capacity() + ", Length: "+ sb1.length());
		System.out.println("String is: "+ sb2 +", Capacity: "+ sb2.capacity() + ", Length: "+ sb2.length());
		System.out.println("String is: "+ sb3 +", Capacity: "+ sb3.capacity() + ", Length: "+ sb3.length());
		
		System.out.println("String inserted at 3rd position in string - "+ sb3.insert(2, sb2)); //update existing string and return it
		
		System.out.println("removing we from string from index 2 (incl) to 4 (excl) - "+ sb3.replace(2, 4, "")); //update existing string and return it
		
		System.out.println("deleting string : lcometrue3.14pn from "+ sb3+", updated string buffer: "+ sb3.delete(7, sb3.length()));  //update existing string and return it
	
		System.out.println("Reverse of string: "+ sb3.reverse()); //update existing string and return it
		
		System.out.println("Char at 3rd pos is: "+ sb3.charAt(2));
		
		System.out.println("Substring from index 1: "+ sb2.substring(1));	//returns new string
		System.out.println("Substring from index 1 to 3: "+ sb2.substring(1, 4));	//returns new string
	
	}
	

}

//Output:
//String is: , Capacity: 16, Length: 0
//String is: welcome, Capacity: 23, Length: 7
//String is: welcometrue3.14pn, Capacity: 34, Length: 17
//String inserted at 3rd position in string - wewelcomelcometrue3.14pn
//removing we from string from index 2 (incl) to 4 (excl) - welcomelcometrue3.14pn
//deleting string : lcometrue3.14pn from welcomelcometrue3.14pn, updated string buffer: welcome
//Reverse of string: emoclew
//Char at 3rd pos is: o
//Substring from index 1: elcome
//Substring from index 1 to 3: elc
