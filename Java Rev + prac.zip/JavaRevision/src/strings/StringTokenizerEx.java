/*
 * StringTokenizer :
 *	It's a class that is used to break string into tokens (small pieces of string depending upon specified delimiter).
 *	
 * Note : Delimiter can be specified while creation of StringTokenizer object or one by one to the tokens.
 * 		  It's deprecated now, so we can use split method of String class.
*/ 

package strings;

import java.util.StringTokenizer;

public class StringTokenizerEx {

	public static void main(String[] args) {
		
		StringTokenizer st1 = new StringTokenizer("Welcome to java!"); //by default " " is delimiter
		System.out.println("No of tokens in String Tokenizer: "+st1.countTokens());
		
		while(st1.hasMoreTokens())	//st1.hasMoreElements() - another way
		{
			System.out.println(st1.nextToken());	//st1.nextElement() - another way
		}
		
		System.out.println("----------------");
		
		StringTokenizer st2 = new StringTokenizer("C&Java,Python");
		while(st2.hasMoreTokens())
			System.out.println(st2.nextToken(","));
		
		System.out.println("----------------");		
		
		StringTokenizer st3 = new StringTokenizer("ab-cd-de=ef", "-");
		while (st3.hasMoreElements()) {
			System.out.println(st3.nextToken());			
		}

	}

}


//Output:
//No of tokens in String Tokenizer: 3
//Welcome
//to
//java!
//----------------
//C&Java
//Python
//----------------
//ab
//cd
//de=ef
