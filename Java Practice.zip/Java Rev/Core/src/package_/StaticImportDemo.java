package package_;
import static java.lang.System.*;
import java.io.File;
import static java.io.File.listRoots;


public class StaticImportDemo {

	public static void main(String[] args) {
		
		out.println("Static Import Demo");	//static member directly accessed using static import, if it's not used then need to specify like System.out
		err.println("Static members of class System are directly accessed."); //static member directly accessed using static import, if it's not used then need to specify like System.err
		
		File []drives = listRoots();	//static method directly accessed using static import, if it's not used then need to specify like File.listRoots()
		
		for(File drive: drives)
		{
			System.out.println("Drive Name: "+ drive.getAbsolutePath()+ " , Available Space: "+ drive.getFreeSpace()+ " , Used Space: "+ (drive.getTotalSpace() - drive.getFreeSpace()));
		}
		
	}

}

//Package: Package is a collection or group of classes, interfaces and enumerations. It can also have sub-packages (they are used to classify all these entities further ex. vehicles_pkg -> twoWheeler_subpkg (Bike, Cycle) , fourWheelers_subpkg - (Car, Bus, ..)). 
//		   1) It is used to group/classify classes, interfaces and enums so that it can be easily maintained/managed.
//		   2) It restricts access (as default & protected members are not accessed outside of a package) and used to remove naming conflicts.
//		   3) Three ways to access packages: 
//				> Import all members of a package (import java.io.*)
//				> Import Required members of a package	(import java.io.File)
//				> Fully Qualified Name	{ java.io.File f = new java.io.File("C:/sample.png"); }
//Static Import: Static import allows programmer to directly access static members of class without class qualification (name). Ex : import static java.io.File.*;
//Import: Import allows to access classes, interface, methods in classes, etc without package qualification. Ex : import java.util.ArrayList;