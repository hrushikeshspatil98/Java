package package_;

public class PackageClassDemo {

	public static void main(String[] args) {
		
		Package pkg = Package.getPackage("java.util");	//Deprecated, avoid using it
		System.out.println("Package Name: "+ pkg.getName() + " Specification Title: "+ pkg.getSpecificationTitle()+" Specification Version: "+ pkg.getSpecificationVersion());
		
		System.out.println("***************");
		
		// get the Packages using getPackages() method
        Package[] packages = Package.getPackages();	//Returns all of the Packages defined by the caller's class loader and its ancestors
  
        for (int i = 0; i < packages.length; i++) {
            System.out.println(packages[i]);
        }

	}
}

//Package Class: It is a class in java.lang package which is used to get information like specification & implementation details of the package.

//Output:

//Package Name: java.util Specification Title: Java Platform API Specification Specification Version: 1.8
//***************
//package java.util, Java Platform API Specification, version 1.8
//package sun.reflect.annotation, Java Platform API Specification, version 1.8
//package java.lang.annotation, Java Platform API Specification, version 1.8
//package java.nio, Java Platform API Specification, version 1.8
//package sun.nio, Java Platform API Specification, version 1.8
//package java.security.cert, Java Platform API Specification, version 1.8
//...