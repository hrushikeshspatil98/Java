package strings;

import java.util.Arrays;

public class StringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Welcome";
		
		//Length
		System.out.println("Length of string "+s1+ " is: "+ s1.length());
		//Concatenation
		System.out.println("Concatenated string is: "+ s1.concat(" to java !"));
		//Lower & Upper case 
		System.out.println("Lower Case String: "+ s1.toLowerCase()+ " Upper Case String: "+ s1.toUpperCase());
		//Two Strings equal or not
		System.out.println(s1+ " equals to welcome ? "+ s1.equals("welcome"));
		System.out.println(s1+ " equals to welcome (ignore case) ? "+ s1.equalsIgnoreCase("welcome"));
		//Get Char at specified position
		System.out.println("2nd char in string "+ s1 + " is: "+ s1.charAt(1));
		//Substring
		System.out.println("1 to 3 : "+ s1.substring(1,4)); // (inclusive index, exclusive index)
		System.out.println("1 to size : "+ s1.substring(1));
		//contains specified string sequence
		System.out.println("is Welcome contains com ? "+ s1.contains("com"));
		//index of char
		System.out.println("index of char l in Welcome is: "+ s1.indexOf('l'));
		System.out.println("index of char e in Welcome is: "+ s1.indexOf('e',3));
		//index of string
		System.out.println("index of string me in Welcome is: "+ s1.indexOf("me"));
		System.out.println("index of string me in Welcome is: "+ s1.indexOf("me",3));
		
		//value of
		System.out.println("Value of "+ String.valueOf(false));
		System.out.println("Value of "+ String.valueOf(3.14));
		System.out.println("Value of "+ String.valueOf(new char[] {'a', 'b', 'c'}));
		System.out.println(String.valueOf(s1.toCharArray(), 3, 2));
		
		//string empty
		System.out.println("is string empty? "+ s1.isEmpty());
		//System.out.println("is string empty? "+ s1.isBlank()); // Java 11 & more
		
		//split string
		String sp[] = s1.split("l");
		Arrays.asList(sp).forEach(System.out::println);
		String sp1[] = s1.split("e", 2); //will return only 2 splitter strings
		Arrays.asList(sp1).forEach(System.out::println);
		
		//remove leading and trailing white spaces
//		String lspace = "  ab", tspace = "ab  ";
//		System.out.println(lspace.strip() + tspace.stripTrailing() + s1.strip()); // Java 11 & more
		System.out.println("Trimmed String is: "+s1.trim());
		
		//Replace char & string
		String repStr = s1.replace('W', 'w');
		System.out.println("Replaced String : "+ repStr + " , original string : "+s1);
		System.out.println(s1.replaceFirst("e", "to"));
		System.out.println(s1.replaceAll("e", "to"));
		System.out.println(s1.replace("e", "to"));
		
		//Starts and ends with
		System.out.println(s1.startsWith("Wel"));
		System.out.println(s1.startsWith("com", 3)); //2nd parameter for specifying from where to start (inclusive)
		System.out.println(s1.endsWith("com"));
		
		//reverse and converting into bytes
		byte []arr = s1.getBytes();
		for(int i=arr.length-1; i>=0; i--)
			System.out.print((char) arr[i]+ " ");
		System.out.println();
		
		//join
		System.out.println(String.join("-", "Welcome", "to" , "java" , "!"));
		System.out.println(String.join("-", Arrays.asList("Welcome", "to" , "java" , "!")));
		
		System.out.println("Formatting: ");
		//format (%c for char, %d for integer, %f for floating point value, %s for string, 
		// %x for hex string, %o for octal string, %t for date & time, %n line separator
		System.out.println(String.format("%d", 100));
		System.out.println(String.format("%c", 'A'));
		System.out.println(String.format("%f", 35.141));
		System.out.println(String.format("%s", "sample"));
		System.out.println(String.format("%o", 19));
		System.out.println(String.format("%x", 121));
		
		System.out.println("|" + String.format("%5d", 101)+"|"); //size of number is 3, so 2 leading spaces will be added
		System.out.println("|" + String.format("%-5d", 101)+"|"); //size of number is 3, so 2 trailing spaces will be added		
		System.out.println("|" + String.format("%05d", 101)+"|"); //applicable for zero only
		//System.out.println("|" + String.format("%-05d", 101)+"|"); //10100 - will not work , so use below alternative
		System.out.println("|" + String.format("%-5d", 101).replace(" ", "0")+"|");
		
		//compare to
		String a = "azc";
		String b = "abcde";
		int num = a.compareTo(b);
		if(num < 0)
			System.out.println(a+" < abcde");
		else if(num > 0)
			System.out.println(a+" > abcde");
		else
			System.out.println(a+" == abcde");
		
		//intern
		String a1=new String("hello");  
		String a2="hello";  
		String a3=new String("hello").intern();//returns string from pool, now it will be same as s2  
		System.out.println(a1==a3);//false because reference is different  
		System.out.println(a2==a3);//true because reference is same 
	}
	
	 

}

/*
 * Output:
 * 
 * Length of string Welcome is: 7
Concatenated string is: Welcome to java !
Lower Case String: welcome Upper Case String: WELCOME
Welcome equals to welcome ? false
Welcome equals to welcome (ignore case) ? true
2nd char in string Welcome is: e
1 to 3 : elc
1 to size : elcome
is Welcome contains com ? true
index of char l in Welcome is: 2
index of char e in Welcome is: 6
index of string me in Welcome is: 5
index of string me in Welcome is: 5
Value of false
Value of 3.14
Value of abc
co
is string empty? false
We
come
W
lcome
Trimmed String is: Welcome
Replaced String : welcome , original string : Welcome
Wtolcome
Wtolcomto
Wtolcomto
true
true
false
e m o c l e W 
Welcome-to-java-!
Welcome-to-java-!
Formatting: 
100
A
35.141000
sample
23
79
|  101|
|101  |
|00101|
|10100|
false
true
*/
