//FileInputStream or FileOutputStream : It is used to read or write single/specified byte of data to or from file. Used to perform IO on binary files.
//FileReader or FileWriter : It is used to read or write single/specified chars of data to or from file. Used to perform IO on text files.
//BufferedInputStream or BufferedOutputStream : It is used to read/write data (in bytes) from internal buffer which contains specified bytes of data to or from another stream at a time.
//												Faster than FileInputStream or FileOutputStream.
//BufferedReader or BufferedWriter: It is used to read/write data (in chars) from internal buffer which contains specified no of chars to or from another stream at a time. 
//									Faster than FileReader or FileWriter.
//BufferedReader provides readLine() method to read whole line of data from stream.

package io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedStream {

	public static void main(String[] args) {
	
		try {
		FileInputStream fis = new FileInputStream("H:/data.txt");
		BufferedInputStream bis = new BufferedInputStream(fis, 28); //default buffered size is 8192 bytes
		//Internally it creates 28 byte buffered array. It will get automatically refilled with data from
		//specified stream. Due to this it increases performance as compared to input/output stream.
		//ex. suppose 56 bytes of data is present in a file. So input stream object makes 56 calls to read data from file
		//but buffered stream makes only 2 calls (28+28 bytes)
		
		int c;
		while((c = bis.read())!= -1)
		{
			System.out.write(c);
		}
		System.out.flush();
		fis.close();
		
		fis = new FileInputStream("H:/data.txt");
		bis = new BufferedInputStream(fis);
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("H:/data_copy.txt"));
		while((c = bis.read())!= -1)
		{
			bos.write(c);
		}
		bos.flush();
		
		//read(byte[]) method demo - will generate same result as above
//		System.out.println("************");
//		byte []arr = new byte[28];
//		while((c = bis.read(arr))!= -1)
//		{
//			System.out.write(arr);
//		}
		
		//Reading remaining bytes in stream in one go -- Java 9 and more.
//		BufferedInputStream b = new BufferedInputStream(new FileInputStream("H:/data.txt"));
//		byte[] arr = b.readAllBytes();
//		System.out.write(arr);
		
		
		
		bis.close();
		bos.close();
		fis.close();
		
		} catch (FileNotFoundException e) {
			System.out.println(e.getLocalizedMessage());
		} catch(IOException e){
			System.out.println(e.getLocalizedMessage());
		}
		
		System.out.println("****************************");
		
		try {
				
			FileReader fr = new FileReader("H:/data_copy.txt");
			FileWriter fw = new FileWriter("H:/data_copy1.txt",true); //write data in append mode
			BufferedReader br = new BufferedReader(fr);
			BufferedWriter bw = new BufferedWriter(fw);
			
			int c;
			while((c = br.read())!= -1)
			{
				//System.out.write(c); //output stream
				//System.out.print((char)c);  //output stream
				bw.write(c);	//buffered stream
			}
			bw.flush();
			
			bw.close();
			fw.close();
			fr.close();
			br.close();
			
			System.out.println("###############################");
			
			br = new BufferedReader(new FileReader("H:/data_copy.txt"));
			String currLine = "";
			while((currLine = br.readLine()) != null)
				System.err.println(currLine);
			
		}
		catch(Exception e) {}
	}
}
