package io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileRead {

	public static void main(String[] args) {
		
		try {
		FileInputStream fis = new FileInputStream("H:\\sample.txt");
		
		int x;
		while ((x = fis.read()) != -1) {
			System.out.write(x);
			//System.out.print((char)x);
		}
		System.out.flush();
		
		fis.close();
		System.out.println("\nData Read Successfully !");
		}
		catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
		
		
	}

}
