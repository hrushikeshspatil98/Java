package io;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileRW1 {

	public static void main(String[] args) {
		String file = "H:/raf_sample.txt";
		String mode = "rw";
		
		try {
			RandomAccessFile raf = new RandomAccessFile(file, mode);
			byte []arr = {97,99,100,101};
			
			raf.write(arr);
			raf.write(102);
			raf.seek(8);
			raf.write('b');
			
			raf.seek(0);
			do
			{
				System.out.write(raf.read());
			}while(raf.getFilePointer() < raf.length());
			System.out.flush();
			
			raf.close();
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

}
