//Stream Redirection:
//	It is feature in java which allows redirecting a stream to another stream.
//	After redirection, stream reads/writes data to/from the redirected source/target
//	It allows redirection of 3 predefined streams : System.in, System.out, System.err
//	Methods used to set streams are setIn(inputStrmObj),setOut(printStrmObj),setErr(printStrmObj)
//	Custom stream does not required redirection as it's are created as per need/choice.

package io;

import java.io.PrintStream;

public class StreamRedirection {

	public static void main(String[] args) {

		try {
			
		System.out.println("This line is printed through system output stream");	
			
		PrintStream ps = new PrintStream("H:/redirectedStreamData.txt");
		
		PrintStream temp = System.out;	//Backup the stream
		
		System.setOut(ps);	//Stream Redirected...Now data will be printed through above file stream instead of system console
		
		System.out.println("This line is printed through system redirected stream");	//writing data to file through redirected stream
		System.out.println("Stream Redirection done successfully !");
		
		System.setOut(temp); //restoring stream (for better practice it should be restored to it's original source stream)
		
		System.out.println("Stream restored..Back to original source..");
		System.out.println("Redirection and restoring it again is important");
		
		}
		catch (Exception e) {
			System.out.println(e.getLocalizedMessage());
		}

	}

}
