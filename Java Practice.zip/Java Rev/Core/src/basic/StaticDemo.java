package basic;

public class StaticDemo {
	static int a = 10;
	final static int b = 20;
	int c = 30;
	
	public static void main(String[] args) { // static method only direct access static members, if want to use non static members create object first & then use
		// TODO Auto-generated method stub
		StaticDemo demo = new StaticDemo();
//		System.out.println("a: "+demo.a+ " b: "+demo.b); //Not preferred: allowed but will get warnings
		System.out.println("a: "+StaticDemo.a+ " b: "+StaticDemo.b+ " c: "+demo.c);
		StaticDemo.a = 30;
		//a = 30;  //another way if accessing in same class
		
		System.out.println("a: "+StaticDemo.a+ " b: "+StaticDemo.b+ " c: "+demo.c);
		
		demo.nonStatMethod();
//		demo.statMethod();  //Not preferred:  allowed but will get warnings
		StaticDemo.statMethod();
	}
	
	void nonStatMethod()
	{
		System.out.println("this is non static method, value of a  is: "+ StaticDemo.a+ " and c is : "+c);
		//System.out.println("this is non static method, value of a  is: "+ a+ " and c is : "+c); //another way
	}

	static void statMethod()
	{
		System.out.println("this is static method, value of a is: "+ a);
		System.out.println("Value of c is : "+ new StaticDemo().c);
	}
}

/*  
 * Output: 
 * a: 10 b: 20 c: 30
a: 30 b: 20 c: 30
this is non static method, value of a  is: 30
this is static method, value of a is: 30
Value of c is : 30
*/
