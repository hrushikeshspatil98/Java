package basic;

class OuterEx2
{
	int x = 10;
	
	void display()
	{
		int y = 20;
		
		class InnerEx2  // We can't define static class here, it needs to be either non static or abstract or final
		{
			double pi = 3.14;
			//static int c = 0; //not allowed - defining static members/methods inside non static inner type
			
			void print()
			{
				System.out.println(pi * x * y);
			}
			
		}
		
		//class InnerEx3 extends InnerEx2{} //allowed
		
		InnerEx2 ex2 = new InnerEx2();
		ex2.print();
		
	}
}
public class LocalInnerClass {

	public static void main(String[] args) {
		OuterEx2 outerEx2 = new OuterEx2();
		outerEx2.display();
	}

}
