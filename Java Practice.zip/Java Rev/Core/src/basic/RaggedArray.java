package basic;
/*
Ragged array is two dimensional array in java that is having fixed number of rows but 
different number of columns. basically it is array containing arrays of different size.
We don't need to specify column size while declaring an array.
Once declared we need to specify different column size of each row in array.

int array[][] = new int[3][];

array[0] = new int[2];
array[1] = new int[3];
array[2] = new int[5];

		or
		
int arr_name[][] = new int[][] {
      new int[] {10, 20, 30 ,40},
      new int[] {50, 60, 70, 80, 90, 100},
      new int[] {110, 120} }
*/

public class RaggedArray {

	public static void main(String[] args) {
		
		int arr[][] = new int[3][];
		
		for(int i=0; i<arr.length ; i++)
		{
			arr[i] = new int[i+1];
			System.out.println(i + " array size is: "+arr[i].length);
		}
			
		for(int i = 0; i < arr.length; i++)
			for(int j=0; j< arr[i].length; j++)
				arr[i][j] = i + 10 + j;
		
		System.out.println("Ragged/ Jagged array : ");
		for(int i = 0; i < arr.length; i++) {
			for(int j=0; j< arr[i].length; j++) {
				System.out.print(arr[i][j]+ " ");
			}
			System.out.println();
		}
				
	}

}

/* Output:
0 array size is: 1
1 array size is: 2
2 array size is: 3
Ragged/ Jagged array : 
10 
11 12 
12 13 14 
*/
