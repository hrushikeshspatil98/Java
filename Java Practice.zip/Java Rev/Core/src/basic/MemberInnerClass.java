package basic;

class OuterEx1
{
	double pi;
	private int c =10;
	static int val = 30;
	
	public OuterEx1() {
		pi = 3.14;
		System.out.println("Inside Outer Class Constructor & val is : "+val);
	}
	
	static { System.out.println("Outer: SIB");	}
	
	class InnerEx1
	{
		int y;
		//static int z= 10;		//static member not allowed in non static inner class , to make it declare inner class as static
		OuterEx1 ou;
		
		InnerEx1()
		{
			System.out.println("Inner : Constructor");
			System.out.println("Value is: "+val);
			ou = new OuterEx1();
		}
		
		{	System.out.println("Inner: NSIB");	}
		
		//static { System.out.println("Inner: SIB");	}  //static initializer not allowed in non static inner Class
		//static void innerStaticMethod(){}				   //static method not allowed in non static inner class
		
		void display()
		{
			System.out.println("Inner Class: display()");
			print();
		}
		
		private void print()
		{
			System.out.println("Primate Methods accessed locally only in inner class, C: "+ c);
		}
	
	}
	
}

public class MemberInnerClass {
	public static void main(String[] args) {
		OuterEx1 outer = new OuterEx1();
		OuterEx1.InnerEx1 inner = outer.new InnerEx1();
		inner.display();
		System.out.println(inner.ou.pi);		
	}
}
