package interfaces;

public class InterfaceTest implements IfaceA{

	public static void main(String[] args) {
		
		IfaceA a = new InterfaceTest();
		a.display();
		IfaceA.valueOfPi();
		System.out.println(a.findArea(3.5 , 2.5));
		System.out.println(a.findAreaOfOthers(5));
		
		InterfaceTest interfaceTest = new InterfaceTest();
		interfaceTest.display();
		System.out.println(InterfaceTest.pi + " or "+ IfaceA.pi); //InterfaceTest.pi - only static data members can be accessed like this, static methods are not allowed using class name that implements interface
		System.out.println(interfaceTest.findArea(3, 4));
		System.out.println(interfaceTest.findAreaOfOthers(10));
		
	}

	@Override
	public double findArea(double a, double b) {
		return 0.5 * a * b;
	}

	@Override
	public double findAreaOfOthers(int r) {
		return IfaceA.pi * r * r;
	}
	
	

}

/*
Output:
Default Method : IfaceA
Value of pi is : 3.14
4.375
78.5
Default Method : IfaceA
3.14 or 3.14
6.0
314.0
*/
