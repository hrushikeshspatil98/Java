package interfaces;

interface Test1
{
	void test1();
}

interface Test2 extends Test1
{
	void test2();
}

interface Test3
{
	void test1();
	void test3();
}

public class MultipleIfaceImpl implements Test2, Test3{

	public static void main(String[] args)
	{
		Test1 test1 = new MultipleIfaceImpl();
		test1.test1(); 
		
		Test2 test2 = new MultipleIfaceImpl();
		test2.test1();
		test2.test2();
	}

	@Override
	public void test1() {
		System.out.println("test1()");
	}

	@Override
	public void test2() {
		System.out.println("test2()");
	}

	@Override
	public void test3() {
		System.out.println("test3()");
	}
}
