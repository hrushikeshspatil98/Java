package interfaces;

public interface IfaceA {
	final static double pi = 3.14;
	
	double findArea(double a, double b);
	double findAreaOfOthers(int r);
	
	default void display()	//Java-8 Feature
	{
		System.out.println("Default Method : IfaceA");
	}
	
	static void valueOfPi()	//Java-8 Feature
	{
		System.out.println("Value of pi is : "+pi);
	}
	
//	Java - 9 Feature :- needs to be accessed within class, can't use outside
//	private void someLogic()
//	{
//		
//	}
	
}
