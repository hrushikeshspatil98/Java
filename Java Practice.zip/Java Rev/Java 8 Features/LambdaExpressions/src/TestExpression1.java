import java.util.ArrayList;
import java.util.List;

@FunctionalInterface
interface LamExprSingleExp
{
	void test();
}

interface LamExprWithSingleParm
{
	double getAreaOfCircle(int radius);
}

interface LamExprWithMulParm
{
	double getAreaOfRectangle(int l, int b);
}

interface LamExprWithMulImpl
{
	void performOperation(int num);
}

public class TestExpression1{

	
	public static void main(String []args)
	{
		LamExprSingleExp exp = () -> System.out.println("This is lambda exp with no body (single body expression) ");
		exp.test();
		
		LamExprWithSingleParm sparam = (radius) -> 3.14 * radius * radius;
		System.out.println(sparam.getAreaOfCircle(12));
		
		LamExprWithMulParm mparam = (l,b) -> l * b;
		System.out.println(mparam.getAreaOfRectangle(12, 8));
		
		List<String> prodList = new ArrayList<String>();
		prodList.add("Ice-Cream");
		prodList.add("Cake");
		prodList.add("Biscuit");
		
		prodList.forEach((item) -> System.out.print(item+ " "));
		
		LamExprWithMulImpl mulImpl, mulImpl1;
		
		mulImpl = (number) -> {
			int result= 1;
			while(number != 0)
			{
				result = result * number;
				--number;
			}
			System.out.println("\nFactorial is: "+result);
		};
		
		mulImpl1 = (number) -> {
			int revNum = 0;
			while(number > 0)
			{
				int s = number % 10;
				revNum = revNum * 10 + s;
				number /= 10;
			}
			System.out.println("Reverse is: "+revNum);
		};
		
		mulImpl.performOperation(8);
		mulImpl1.performOperation(910798);
				
	}
	
}
