@FunctionalInterface
interface GenericLamExpr<T,R>
{
	R func(T t);
}

public class TestExpression2{

	
	public static void main(String []args)
	{
				
		GenericLamExpr<Integer,Long> factorial = (number) -> {
			long result= 1;
			while(number != 0)
			{
				result = result * number;
				--number;
			}
			return result;
		};
		
		GenericLamExpr<String,String> reverse = (str) -> {
			String revStr = "";
			for(int i= str.length()-1 ; i>=0 ; i--)
			{
				revStr += str.charAt(i);
			}
			return revStr;
		};
		
		System.out.println("Factorial of 20 is : "+factorial.func(20));
		System.out.println("Reverse of ABCD string is : "+reverse.func("ABCDEFGHIJKLMNOP"));
		
	}
	
}
