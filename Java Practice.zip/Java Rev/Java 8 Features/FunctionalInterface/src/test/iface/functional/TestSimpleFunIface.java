package test.iface.functional;

public class TestSimpleFunIface implements CalculateInterface , CalculationInterface, SquareRoot {

	@Override
	public int calculate(int value) {
		return value * value;
	}
	
	public static void main(String []args) {
		TestSimpleFunIface testSimpleFunIface = new TestSimpleFunIface();
		System.out.println(testSimpleFunIface.calculate(19));
		
		System.out.println(testSimpleFunIface.square(19));
		
		testSimpleFunIface.defMethod();
		
		System.out.println(CalculationInterface.squareAnyNum(19));
		
		System.out.println("Square Root of 361 is: "+testSimpleFunIface.getSqRoot(361));
	}

	@Override
	public int square(int num) {
		return num * num;
	}
	
	@Override
	public double getSqRoot(double num)
	{
		return Math.sqrt(num);
	}

}

@FunctionalInterface
interface SquareRoot extends NonFunInterface{
	
	double getSqRoot(double num);
}
