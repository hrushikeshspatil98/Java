package test.iface.functional;

@FunctionalInterface
public interface CalculationInterface {
	int num = 0;
	int square= 0;
	
	int square(int num); //Single Abstract Method
	
	
	//Functional Interface can contain any number of default and static methods
	default void defMethod()
	{
		System.out.println("This is default method in functional interface"); 
	}
	
	static double squareAnyNum(double num)
	{
		System.out.println("This is static method in functional interface");
		return num * num;
	}
	
	//Functional Interface can contain any number of Object class methods
	String toString();
	boolean equals(Object o);
}
