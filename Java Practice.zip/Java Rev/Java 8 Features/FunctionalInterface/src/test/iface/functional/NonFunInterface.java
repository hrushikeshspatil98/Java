package test.iface.functional;

public interface NonFunInterface {
	
	default void info()
	{
		System.out.println("Called non functional interface default method");
	}
}
