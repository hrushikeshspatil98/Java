import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class TestStreamMiscOps {

	public static void main(String[] args) {
		
		Stream<Integer> stream = Stream.of(1,2,4,6,8,9,19);
		
		//System.out.println("First element in stream is: "+stream.findFirst().get());
		Optional<Integer> op =stream.findFirst();
		op.ifPresent(value -> System.out.print("First Element: "+value));
		
		Optional<Integer> anyElem = Stream.of(1,2,4,6,8,9,19).findAny();
		anyElem.ifPresent(value -> System.out.print("\nAny Element in Stream: "+value));
		
		List<Integer> list = new ArrayList<Integer>(Arrays.asList(1,2,4,6,8,19));
		
		boolean isNoneMatch = list.stream().noneMatch(val -> val %9 != 0);
		System.out.println("\n"+isNoneMatch);
		
		boolean isAnyMatch = list.stream().anyMatch(val -> val % 2 == 0);
		System.out.println(isAnyMatch);
		
		boolean isAllMatch = list.stream().allMatch(val -> val % 2 == 0);
		System.out.println(isAllMatch);
		
	}

}
